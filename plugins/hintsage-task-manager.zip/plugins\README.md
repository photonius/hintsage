The archive must be fully extracted into the program folder so that a plugins folder appears inside the program directory.
Do not extract individual files and do not improvise or try to change anything — simply extract the archive as it is.
After that, enable the hide option in the Task Manager.

Архив надо полностью распаковать в папку программы так, чтобы в папке программы появилась папка plugins. 
Не надо распаковывать отдельные файлы, не надо ничего придумывать и додумывать, просто распаковать и после этого поставить галку скрытия в диспетчере задач.